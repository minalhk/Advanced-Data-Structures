import java.util.Scanner;

abstract class stack
{
	public int Top;
	void method1()
	{
		push();
		display();
	}
	void method2()
	{
		pop();
		display();
	}
	protected void InitializeStack()
	{
		Top=-1;
	}
	abstract protected void push();
	abstract protected void pop();
	abstract protected void display();
	Scanner sc=new Scanner(System.in);
	int cnt,ch;
	void function()
	{
		InitializeStack();
	do{
		System.out.println("\n1) PUSH");
		System.out.println("\n2) POP");
		System.out.println("\n3) Display");
		System.out.println("\n4) Exit");
		System.out.println("\nEnter Your Choice:");
        ch=sc.nextInt();
        do{
         cnt=0;
        switch(ch)
        {
           case 1:method1();
                  break;
           case 2:method2();
           		  break;
 		   case 3:display();
  	              break;
           case 4:break;
           default:System.out.println("\nPlease Enter correct choice");
           		   ch=sc.nextInt();
                   cnt=1;
        }
        }while(cnt==1);
    }while(ch!=4);
}
}
class IntStack extends stack
{
	int[] stack=new int[7]; int n;
	Scanner sc=new Scanner(System.in);
	protected void push()
	{
		System.out.println("\nEnter Element to PUSH");
		n=sc.nextInt();
		try
		{
			RuntimeException re=new RuntimeException("Stack OverFlow while PUSHing..!");
			if(Top==6)
				throw re;
			else
			{
				Top++;
				stack[Top]=n;
			}
		}
		catch(RuntimeException ret)
		{
			System.out.println("\nException Caught:- "+ ret);
		}
	
	}
	protected void pop()
	{
		try
		{
			RuntimeException re=new RuntimeException("Stack UnderFlow while POPing..!");
			if(Top==-1)
				throw re;
			else
			{
				System.out.println(stack[Top]+" Poped");
				Top--;
			}
		}
		catch(RuntimeException ret)
		{
			System.out.println("\nException Caught:- "+ ret);
		}
	}
	protected void display()
	{
		try
		{
			RuntimeException re=new RuntimeException("Stack UnderFlow while Display..!");
			if(Top==-1)
				throw re;
			else
			{
				System.out.println("\nElements are\n");
				for(int i=0;i<=Top;i++)
					System.out.println(stack[i]+"\t");
			}
		}
		catch(RuntimeException ret)
		{
			System.out.println("\nException Caught:- "+ ret);
		}
	}
}
class CharStack extends stack
{
	char[] stack=new char[7]; char n;
	Scanner sc=new Scanner(System.in);
	protected void push()
	{
		System.out.println("\nEnter Element to PUSH");
		n=sc.next().charAt(0);
		try
		{
			RuntimeException re=new RuntimeException("Stack OverFlow while PUSHing..!");
			if(Top==6)
				throw re;
			else
			{
				Top++;
				stack[Top]=n;
			}
		}
		catch(RuntimeException ret)
		{
			System.out.println("\nException Caught:- "+ ret);
		}
	
	}
	protected void pop()
	{
		try
		{
			RuntimeException re=new RuntimeException("Stack UnderFlow while POPing..!");
			if(Top==-1)
				throw re;
			else
			{
				System.out.println(stack[Top]+" Poped");
				Top--;
			}
		}
		catch(RuntimeException ret)
		{
			System.out.println("\nException Caught:- "+ ret);
		}
	}
	protected void display()
	{
		try
		{
			RuntimeException re=new RuntimeException("Stack UnderFlow while Display..!");
			if(Top==-1)
				throw re;
			else
			{
				System.out.println("\nElements are\n");
				for(int i=0;i<=Top;i++)
					System.out.println(stack[i]+"\t");
			}
		}
		catch(RuntimeException ret)
		{
			System.out.println("\nException Caught:- "+ ret);
		}
	}
}
class template
{
   public static void main(String args[])
   {
	    System.out.println("\n___________Integer Stack____________");
	    IntStack I1=new IntStack();
	    I1.function();
	    
	    System.out.println("\n___________Character Stack____________");
	    CharStack I2=new CharStack();
	    I2.function();
   }
}