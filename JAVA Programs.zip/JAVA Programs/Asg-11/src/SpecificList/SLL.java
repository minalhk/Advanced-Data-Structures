package SpecificList;
import Common.commonlist;

import java.util.Scanner;

class node
{
	public int data;
	public node next;
    public node()
	 {
		 data=-1;
		 next=null;
     }
    public node(int d)
	 {
		 data=d;
		 next=null;
    }
}
public class SLL implements commonlist{

	node head,tail;
	SLL()
	{
		head=null;
		tail=null;
	}
	public void add(int x)
	{
		node temp=new node(x);
		if(head==null)
			head=temp;
		else
		{
			tail.next=temp;
			tail=temp;
		}
		
	}
	public void delete(int x)
	{
		if(head.data==x)
		{
			head=head.next;
			return;
		}
		node temp2;
		temp2=head;
		for(node temp=head.next;temp!=null;temp=temp.next)
		{
			if(temp.data==x)
			{
				temp2.next=temp.next;
				return;
			}
			temp2=temp2.next;	
		}
		System.out.println("Element not Found");
	}
	public int size()
	{
		int cnt=0;
		for(node temp=head;temp!=null;temp=temp.next)
			cnt++;
		return cnt;
	}
	public boolean isempty()
	{
		if(head==null)
			return true;
		return false;
	}
	public void display()
	{
		System.out.println("\nLinked list is\n");
		for(node temp=head;temp!=null;temp=temp.next)
			System.out.println(temp.data+"\t");
	}
	public static void main(String[] args)
	{
		SLL S1=new SLL();
		int ch,n,cnt;
		boolean m;
		Scanner sc=new Scanner(System.in);
		do{
			System.out.println("\n1) Insert");
			System.out.println("\n2) Delete");
			System.out.println("\n3) Size");
			System.out.println("\n4) Is Empty?");
			System.out.println("\n5) Display");
			System.out.println("\n6) Exit");
			System.out.println("\nEnter Your Choice:");
			ch=sc.nextInt();
			do{
			cnt=0;
			switch(ch)
            {
               case 1:System.out.println("\nEnter the Elements");
            	      while(sc.hasNextInt())
       		          {
       		          	int no=sc.nextInt();
       		         	S1.add(no);
       		          }
	                  break;
	           case 2:System.out.println("\nEnter the value to delete");
	                  n=sc.nextInt();
	        	      S1.delete(n);
	                  break;
	           case 3:n=S1.size();
	                  System.out.println("\nSize = "+n);
	  	              break;
     		   case 4:if(S1.isempty())
     		        	 System.out.println("\nLinked list is empty");
     		          else
     		        	 System.out.println("\nLinked list is NOT empty");
     			      break;
     		   case 5:S1.display();
	                  break;
     		   case 6:break;
               default:System.out.println("\nPlease enter the correct choice:");
                       ch=sc.nextInt();
                       cnt=1;
            }
           }while(cnt==1);
         }while(ch!=6);
	}
}