package Common;

public interface commonlist {
	
	void add(int x);
	void delete(int x);
	void display();
	int size();
	boolean isempty();
	
}
