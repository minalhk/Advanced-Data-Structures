import java.util.ArrayDeque;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.Scanner;
import java.util.Stack;

public class DataStruct {

	Scanner sc=new Scanner(System.in);
	int n,ch;
	void main_function()
	{
      int choice;
	  do
	  {
		System.out.println("***********Data_Structure**********");
		System.out.println("1) Linked List\n"+"2) Stack\n"+"3) Priority Queue\n"+"4) DeQueue\n"+"5) HashSet\n"+"6) Exit");
		choice=sc.nextInt();
		switch(choice)
		{
		  case 1:Linked();
		  		 break;
		  case 2:Stack();
		         break;
		  case 3:Queue();
		         break;
		  case 4:DeQueue();
		         break;
		  case 5:HashSet();
		         break;
		  case 6:break;
		  default:System.out.println("Wrong Choice");
		}
	  }while(choice!=6);	
	}
	void Linked()
	{ 
		LinkedList<Integer> l=new LinkedList<Integer>();
		do
		  {
			System.out.println("1) Add First\n"+"2) Add Last\n"+"3) Remove First\n"+"4) Remove Last\n"+"5) Display List\n"+"6) Exit");
			ch=sc.nextInt();
			switch(ch)
			{
			  case 1:System.out.println("Enter number to add First :");
			         n=sc.nextInt();
			         l.addFirst(n);
			  		 break;
			  case 2:System.out.println("Enter number to add Last :");
		         	 n=sc.nextInt();
		         	 l.addLast(n);
		         	 break;
			  case 3:if(l.isEmpty())
				     {System.out.println("Linked List is Empty");
				      break;
				     }
				     System.out.println("Element removed from First is "+l.removeFirst());
		         	 break;
			  case 4:if(l.isEmpty())
			         {System.out.println("Linked List is Empty");
			          break;
			         }
				     System.out.println("Element removed from Last is "+l.removeLast());
			         break;
			  case 5:System.out.println("Linked List  is\n"+l);
			         break;
			  case 6:break;
			  default:System.out.println("Wrong Choice");
			}
		  }while(ch!=6);	
	}
	void Stack()
	{ 
		Stack<Integer> st=new Stack<Integer>();
		do
		  {
			System.out.println("1) Push\n"+"2) Pop\n"+"3) Display Top\n"+"4) IsEmpty ?\n"+"5) Exit\n");
			ch=sc.nextInt();
			switch(ch)
			{
			  case 1:System.out.println("Enter number to Push :");
			         n=sc.nextInt();
			         st.push(n);
			  		 break;
			  case 2:if(st.isEmpty())
			         {System.out.println("Stack is Empty");
			          break;
			         }
				     System.out.println("Poped Element is :"+st.pop());
		         	 break;
			  case 3:if(st.isEmpty())
		             {System.out.println("Stack is Empty");
		              break;
		             }
				     System.out.println("Top of the Stack is :"+st.peek());
		         	 break;
			  case 4:if(st.isEmpty())
				         System.out.println("Stack is empty");
			  		 else
			  			 System.out.println("Stack is NOT empty");
			         break;
			  case 5:break;
			  default:System.out.println("Wrong Choice");
			}
		  }while(ch!=5);	
	}
	void Queue()
	{ 
		PriorityQueue<Integer> pq=new PriorityQueue<Integer>();
		do
		  {
			System.out.println("1) Add\n"+"2) Remove\n"+"3) Display Front\n"+"4) Size\n"+"5) IsEmpty ?\n"+"6) Exit\n");
			ch=sc.nextInt();
			switch(ch)
			{
			  case 1:System.out.println("Enter number to Add :");
			         n=sc.nextInt();
			         pq.add(n);
			  		 break;
			  case 2:if(pq.isEmpty())
		             {System.out.println("Priority Queue is Empty");
		              break;
		             }
				     System.out.println("Poped Element is :"+pq.poll());
		         	 break;
			  case 3:if(pq.isEmpty())
	                 {System.out.println("Priority Queue is Empty");
	                  break;
	                 }
				     System.out.println("Top of the Priority Queue is :"+pq.peek());
		         	 break;
			  case 4:System.out.println("Size of the Priority Queue is :"+pq.size());
			         break;
			  case 5:if(pq.isEmpty())
			             System.out.println("Priority queue is empty");
		  		     else
		  			     System.out.println("Priority queue is NOT empty");
		             break;       
			  case 6:break;
			  default:System.out.println("Wrong Choice");
			}
		  }while(ch!=6);	
	}
	void DeQueue()
	{ 
		ArrayDeque<Integer> dq=new ArrayDeque<Integer>();
		do
		  {
			System.out.println("1) Add Front\n"+"2) Add Rear\n"+"3) Display Front\n"+"4) Display Rear\n"+"5) Pop Front\n"+"6) Pop Rear\n"+"7) Exit\n");
			ch=sc.nextInt();
			switch(ch)
			{
			  case 1:System.out.println("Enter number to Add Front :");
			         n=sc.nextInt();
			         dq.addFirst(n);
			  		 break;
			  case 2:System.out.println("Enter number to Add Rear :");
		         	 n=sc.nextInt();
		         	 dq.addLast(n);
		         	 break;
			  case 3:if(dq.isEmpty())
	                 {System.out.println("DeQueue is Empty");
	                  break;
	                 }
				     System.out.println("Front of the DeQueue is :"+dq.peekFirst());
		         	 break;
			  case 4:if(dq.isEmpty())
                      {System.out.println("DeQueue is Empty");
                       break;
                      }
				     System.out.println("Last of the DeQueue is :"+dq.peekLast());
			         break;
			  case 5:if(dq.isEmpty())
                      {System.out.println("DeQueue is Empty");
                       break;
                      }
				     System.out.println("Poped Element from Front is :"+dq.pollFirst());
		             break;       
			  case 6:if(dq.isEmpty())
                     {System.out.println("DeQueue is Empty");
                       break;
                     }
				     System.out.println("Poped Element from Last is :"+dq.pollLast());
				     break;
			  case 7:break;
			  default:System.out.println("Wrong Choice");
			}
		  }while(ch!=7);	
	}
	void HashSet()
	{
		HashSet<Integer> hs=new HashSet<Integer>();
		do
		  {
			System.out.println("1) Add\n"+"2) Remove\n"+"3) Display\n"+"4) Size\n"+"5) IsEmpty ?\n"+"6) Exit\n");
			ch=sc.nextInt();
			switch(ch)
			{
			  case 1:System.out.println("Enter number to Add :");
			         n=sc.nextInt();
			         hs.add(n);
			  		 break;
			  case 2:System.out.println("Enter number to be Remove :");
		         	 n=sc.nextInt();
		         	 hs.remove(n);
		         	 break;
			  case 3:System.out.println("HashSet is\n"+hs);
		         	 break;
			  case 4:System.out.println("Size of the HashSet is :"+hs.size());
			         break;
			  case 5:if(hs.isEmpty())
			             System.out.println("HashSet is empty");
		  		     else
		  			     System.out.println("HashSet is NOT empty");
		             break;       
			  case 6:break;
			  default:System.out.println("Wrong Choice");
			}
		  }while(ch!=6);	
	}
	public static void main(String args[])
	{
		DataStruct DS=new DataStruct();
		DS.main_function();
	}
}
